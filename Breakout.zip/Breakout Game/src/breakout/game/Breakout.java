/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package breakout.game;


import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

/**
 *
 * @author User
 */
public class Breakout extends Application {
    
     // set up the scene 
    static Canvas canvas = new Canvas(1000, 700);
    static GraphicsContext context = canvas.getGraphicsContext2D();
    static Group root = new Group(canvas);
    static Scene scene = new Scene(root,1000,700);
    static ArrayList<Brick> bricks = new ArrayList<>();
     
     
    // class for creating each body part of snake 
   public static class Ball{
	int centerX;
	int centerY;
        int radius;
        int velocityX;
        int velocityY;
        
	public Ball(int x, int y,int radius,int velocityX,int velocityY) {
		this.centerX = x;
		this.centerY = y;
                this.radius=radius;
                this.velocityX=velocityX;
                this.velocityY=velocityY;
	}

}
   
   // class for creating each body part of snake 
   public static class Brick{
	int startX;
        int startY;
        boolean destroyed;
        
	public Brick(int x,int y) {
		this.startX=x;
                this.startY=y;
                this.destroyed=false;
	}

}
   
   static Random rand = new Random();
  
   // create paddle 
    static int  paddleX=rand.nextInt(875)+125;
    static int  paddleY=670;
       
       // create ball 
    static int randomX=rand.nextInt(950)+50;
    static int randomY=rand.nextInt(450)+300;
    static String direction="";
    static int bricksLeft=48;
    
    Ball ball = new Ball(randomX,randomY,20,6,6);
    
   static int row,col,i;
   
   public static void createBricks(){
       
       // create paddle 
       paddleX=rand.nextInt(875)+125;
       paddleY=670;
       
       // create ball 
       randomX=rand.nextInt(950)+50;
       randomY=rand.nextInt(450)+300;
       
       
       Ball ball = new Ball(randomX,randomY,20,7,7);
       
       // create bricks
       for(row=1;row<=6;row++){
           
           for(col=1;col<=8;col++){
               
                bricks.add(new Brick(col*100,row*40));
           }
       }
   }

    @Override
    public void start(Stage primaryStage) {
       
        createBricks();
        
        // control
	scene.addEventFilter(KeyEvent.KEY_PRESSED, key -> {
            
            if (key.getCode() == KeyCode.A ) {
		direction ="left";
            }
            
	    if (key.getCode() == KeyCode.D ) {
		direction="right";
	    }

	});
        
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {

            @Override
            public void run() {
                
                
                 // clear the screen
                context.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());

                // draw background
                context.setFill(Color.BLACK);
                context.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());

                // move paddle 
                if(direction =="left" && paddleX>=0){
                    paddleX-=10;
                }
                else if(direction =="right" && paddleX+125<=1000){
                    paddleX+=10;
                }
                
                // paddle and  ball collision detection 
                

                if( paddleX<ball.centerX+ball.radius && paddleX+125>ball.centerX-ball.radius && paddleY<ball.centerY+ball.radius && paddleY+30>ball.centerY-ball.radius){
                    ball.velocityY=-ball.velocityY;
                }


                // if ball hits block 
                for(i=0;i<=bricks.size()-1;i++){
                    
                    if(!bricks.get(i).destroyed){
                        
                        // collision detection
                        if( bricks.get(i).startX<ball.centerX+ball.radius && bricks.get(i).startX+100>ball.centerX-ball.radius && bricks.get(i).startY<ball.centerY+ball.radius && bricks.get(i).startY+40>ball.centerY-ball.radius){
                            ball.velocityY=-ball.velocityY;
                            bricks.get(i).destroyed=true;
                            bricksLeft--;
                         }
                        
                  
                    }
                }
                // if ball hits boundary
                if(ball.centerX<=0 || ball.centerX>=1000){
                    ball.velocityX=-ball.velocityX;
                    
                }
                
                if(ball.centerY<=0){
                    ball.velocityY=-ball.velocityY;
                    
                }
                
                // restart condition 
                if(ball.centerY>=700){
                   
                    for(i=0;i<=bricks.size()-1;i++){
                        bricks.get(i).destroyed=false;
                    }
                    ball.velocityY=-ball.velocityY;
                    bricksLeft=48;
                }
                
                // win condition 
                if(bricksLeft==0){
                    for(i=0;i<=bricks.size()-1;i++){
                        bricks.get(i).destroyed=false;
                    }
                    bricksLeft=48;
                }
                 // draw bricks 
                for(i=0;i<=bricks.size()-1;i++){
                    if(!bricks.get(i).destroyed){
                        if(bricks.get(i).startY==40){
                            context.setFill(Color.RED);
                        }
                        else if(bricks.get(i).startY==80){
                            context.setFill(Color.ORANGE);
                        }
                        else  if(bricks.get(i).startY==120){
                            context.setFill(Color.YELLOW);
                        }
                        else   if(bricks.get(i).startY==160){
                            context.setFill(Color.GREEN);
                        }
                        else if(bricks.get(i).startY==200){
                            context.setFill(Color.BLUE);
                        }
                        else if(bricks.get(i).startY==240){
                            context.setFill(Color.PURPLE);
                        }
                        context.fillRect(bricks.get(i).startX,bricks.get(i).startY,100,40);
                    }
                }
                
                 // draw ball 
                context.setFill(Color.WHITE);
                context.fillOval(ball.centerX,ball.centerY,ball.radius,ball.radius);
                
                // draw paddle 
                context.fillRect(paddleX,paddleY,125,30);
                
                // move ball 
                ball.centerX+=ball.velocityX;
                ball.centerY+=ball.velocityY;
            }
        },0,20); 
        
        // show stage
        primaryStage.setScene(scene);
	primaryStage.setTitle("Breakout");
	primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

  
    
}
