
package snake;

import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.scene.Group;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import static snake.SnakeGameTriplePlayer.greenRandomX;


public class SnakeGameDoublePlayer extends Application {
    
    // global variables 
   static ArrayList<BodyPart> greenBody = new ArrayList<>();
   static int greenRandomX,greenRandomY;
   static int greenHeadX,greenHeadY;
   static String greenDirection;
   static int greenLength=1;
   
   static ArrayList<BodyPart> blueBody = new ArrayList<>();
   static int blueRandomX,blueRandomY;
   static int blueHeadX,blueHeadY;
   static String blueDirection;
   static int blueLength=1;
   
   static int i,randomNum;
   static boolean invalidPlacement;
   static int foodRandomX,foodRandomY;
   static int foodX,foodY;
   static Random rand = new Random();
   static Timer timer = new Timer(); 
   
   // set up the scene 
    static Canvas canvas = new Canvas(1280, 640);
    static GraphicsContext context = canvas.getGraphicsContext2D();
    static Group root = new Group(canvas);
    static Scene scene = new Scene(root,1280,640);
    
    // class for creating each body part of snake 
   public static class BodyPart {
	int x;
	int y;

	public BodyPart(int x, int y) {
		this.x = x;
		this.y = y;
	}
    }
    

   public static void createFood(){
       
       invalidPlacement = true;
       
       while(invalidPlacement){
            foodRandomX=rand.nextInt(37)+1;
            foodRandomY=rand.nextInt(17)+1;
            
            invalidPlacement=false;
            
            // do not put food on same square as green snake 
	    for(i=0;i<=greenBody.size()-1;i++){
						
		if(foodRandomX*32 == greenBody.get(i).x && foodRandomY*32 == greenBody.get(i).y){
		    invalidPlacement=true;
		}
	    }
            
            // do not put food on same square as blue snake 
	    for(i=0;i<=blueBody.size()-1;i++){
						
		if(foodRandomX*32 == blueBody.get(i).x && foodRandomY*32 == blueBody.get(i).y){
		    invalidPlacement=true;
		}
	    }
        }
       
       foodX=foodRandomX*32;
       foodY=foodRandomY*32;
   }

   public static void declareWinner(){
       
       if(greenLength > blueLength){
           System.out.println("Blue wins");
       }
       else if(blueLength > greenLength){
           System.out.println("Green wins");
       }
       else if(greenLength == blueLength){
           System.out.println("Tie");
       }
   }
   
    @Override
    public void start(Stage primaryStage){
        
        // control
	scene.addEventFilter(KeyEvent.KEY_PRESSED, key -> {
            if (key.getCode() == KeyCode.W ) {
		greenDirection="up";
            }
            if (key.getCode() == KeyCode.A ) {
		greenDirection ="left";
            }
            if (key.getCode() == KeyCode.S ) {
		greenDirection="down";
	    }
	    if (key.getCode() == KeyCode.D ) {
		greenDirection="right";
	    }
            if (key.getCode() == KeyCode.T) {
		blueDirection="up";
            }
            if (key.getCode() == KeyCode.F) {
		blueDirection ="left";
            }
            if (key.getCode() == KeyCode.G ) {
		blueDirection="down";
	    }
	    if (key.getCode() == KeyCode.H ) {
		blueDirection="right";
	    }

	});
        
        // create green snake head 
        greenRandomX=rand.nextInt(37)+1;
        greenRandomY=rand.nextInt(17)+1;
				
	greenHeadX = greenRandomX*32;
	greenHeadY = greenRandomY*32;
				
	greenBody.add(new BodyPart(greenHeadX,greenHeadY));
	
        // create blue snake head 
	blueRandomX=rand.nextInt(37)+1;
        blueRandomY=rand.nextInt(17)+1;
					
	while(greenRandomX == blueRandomX && greenRandomY == blueRandomY){
            blueRandomX=rand.nextInt(37)+1;
            blueRandomY=rand.nextInt(17)+1;
	}
					
	blueHeadX = blueRandomX*32;
	blueHeadY = blueRandomY*32;
							
	blueBody.add(new BodyPart(blueHeadX,blueHeadY));
        
        // update screen every 55 milliseconds 
        timer.scheduleAtFixedRate(new TimerTask() {

            @Override
            public void run() {
                
                // clear the screen
                context.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());

                // move green snake head
		if(greenDirection == "left" && greenHeadX>0){
                    greenHeadX-=32;
		}
		else if(greenDirection == "right" && greenHeadX<1248){
                    greenHeadX+=32;
		}
		else if(greenDirection == "up" && greenHeadY>0){
                    greenHeadY-=32;
		}
                else if(greenDirection == "down" && greenHeadY<608){
                    greenHeadY+=32;
		}
                
                 // move blue snake head
		if(blueDirection == "left" && blueHeadX>0){
                    blueHeadX-=32;
		}
		else if(blueDirection == "right" && blueHeadX<1248){
                    blueHeadX+=32;
		}
		else if(blueDirection == "up" && blueHeadY>0){
                    blueHeadY-=32;
		}
                else if(blueDirection == "down" && blueHeadY<608){
                    blueHeadY+=32;
		}
                
                
                // food has been eaten by green snake 
		if(greenBody.get(0).x == foodX && greenBody.get(0).y== foodY){
               
                    createFood();
                    greenBody.add(new BodyPart(greenHeadX,greenHeadY));
                    greenLength++;
		}
                
                 // food has been eaten by blue snake 
		if(blueBody.get(0).x == foodX && blueBody.get(0).y== foodY){
               
                    createFood();
                    blueBody.add(new BodyPart(blueHeadX,blueHeadY));
                    blueLength++;
		}
                
                // collision detection for green snake 
		for(i=1;i<=greenBody.size()-1;i++){
					
                    if(greenBody.get(0).x == greenBody.get(i).x && greenBody.get(0).y == greenBody.get(i).y){
                        
			greenLength=1;
                        greenBody.clear();
                        greenBody.add(new BodyPart(greenHeadX,greenHeadY));
                        
                    }
		}
                
                // collision detection for blue snake 
		for(i=1;i<=blueBody.size()-1;i++){
					
                    if(blueBody.get(0).x == blueBody.get(i).x &&  blueBody.get(0).y == blueBody.get(i).y){
                        
                        blueLength=1;
                        blueBody.clear();
                        blueBody.add(new BodyPart(blueHeadX,blueHeadY));
                    }	
                }
		
                
                // green snake head hits blue snake's body 
		for(i=1;i<=blueBody.size()-1;i++){
						
                    if(greenBody.get(0).x == blueBody.get(i).x && greenBody.get(0).y == blueBody.get(i).y){
			
                        greenLength=1;
			greenBody.clear();
                        greenBody.add(new BodyPart(greenHeadX,greenHeadY));
                    }		
                }
					
		// blue snake head hits green snake's body 
		for(i=1;i<=greenBody.size()-1;i++){
						
                    if(blueBody.get(0).x == greenBody.get(i).x && blueBody.get(0).y == greenBody.get(i).y){
			
                        blueLength=1;
			blueBody.clear();
                        blueBody.add(new BodyPart(blueHeadX,blueHeadY));
                    }		
                }
					
		// the heads of the two snakes collide 
		if(greenBody.get(0).x == blueBody.get(0).x && greenBody.get(0).y == blueBody.get(0).y){
                    
                    if(greenLength > blueLength){
                        greenLength=1;
			greenBody.clear();
                        greenBody.add(new BodyPart(greenHeadX,greenHeadY));
                    }
                    
                    else if(blueLength > greenLength){
                        blueLength=1;
			blueBody.clear();
                        blueBody.add(new BodyPart(blueHeadX,blueHeadY));
                    }
                    
                    else if(greenLength == blueLength){
                        
                        randomNum = rand.nextInt(2)+1;
                        
                        if(randomNum == 1){
                            greenLength=1;
                            greenBody.clear();
                            greenBody.add(new BodyPart(greenHeadX,greenHeadY));
                        }
                        
                        else if(randomNum == 2){
                            blueLength=1;
                            blueBody.clear();
                            blueBody.add(new BodyPart(blueHeadX,blueHeadY));
                        }
                    }
                }
                
                // green snake hits the border 
		if(greenBody.get(0).x <=0 || greenBody.get(0).x >=1248 || greenBody.get(0).y <=0 || greenBody.get(0).y >=608){
					
                    greenLength=1;
                    greenBody.clear();
                    greenBody.add(new BodyPart(greenHeadX,greenHeadY));
		}
                
                // blue snake hits the border 
		if(blueBody.get(0).x <=0 || blueBody.get(0).x >=1248 || blueBody.get(0).y <=0 || blueBody.get(0).y >=608){
					
                    blueLength=1;
                    blueBody.clear();
                    blueBody.add(new BodyPart(blueHeadX,blueHeadY));
		}
                
                // move green snake forward
		greenBody.remove(greenBody.size()-1);
		greenBody.add(0,new BodyPart(greenHeadX,greenHeadY));
		
                // move blue snake forward
		blueBody.remove(blueBody.size()-1);
		blueBody.add(0,new BodyPart(blueHeadX,blueHeadY));
                
		// draw food 
		context.setFill(Color.RED);
		context.fillRect(foodX,foodY,32,32);
                
                // draw green snake body
                context.setFill(Color.GREEN);
		for(i=0;i<=greenBody.size()-1;i++){
							
                    context.fillRect(greenBody.get(i).x,greenBody.get(i).y,32,32);
		}
                
                // draw blue snake body
                context.setFill(Color.BLUE);
		for(i=0;i<=blueBody.size()-1;i++){
							
                    context.fillRect(blueBody.get(i).x,blueBody.get(i).y,32,32);
		}
            }
        },0,50); 
        
        // show stage
        primaryStage.setScene(scene);
	primaryStage.setTitle("Snake Game Doubleplayer");
	primaryStage.show();
    }


    // launch application 
    public static void main(String[] args) {
        launch(args);
    }
    
}
